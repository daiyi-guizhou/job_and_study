# 高频面试系列

8 说了，本章都是高频面试题，配合前面的动态规划系列，祝各位马到成功！

欢迎关注我的公众号 labuladong，方便获得最新的优质文章：

![labuladong二维码](../pictures/qrcode.jpg)