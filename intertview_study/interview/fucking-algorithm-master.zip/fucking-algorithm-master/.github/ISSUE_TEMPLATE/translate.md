---
name: 参与翻译
about: 我想参与仓库中文章的翻译工作
title: 'translate '
labels: translate
assignees: ''

---

<!-- 标题为“translate + 你要翻译的文章的完整文件路径”，比如“translate 动态规划系列/抢房子.md” -->

<!-- 内容一定要按照以下模板，根据你的具体内容进行修改。 -->

<!-- 若想翻译多篇文章，请开启多个 issue，不要挤在同一个 issue 中发布。 -->

<!-- 注释不会显示在 issue 中，下面的内容只需修改两处，文章名字和翻译时间 -->

我已阅读过[翻译组工作流程](https://github.com/labuladong/fucking-algorithm/issues/9)，我已阅读过[翻译要求](https://github.com/labuladong/fucking-algorithm/blob/english/README.md)，我已查看 [已完成列表](https://github.com/labuladong/fucking-algorithm/pulls?q=is%3Apr+is%3Aclosed)，确保我要翻译的文章还没有被翻译。

我将开始翻译如下文章（点击可查看目标文章）：

<!-- 此处修改为你选择的文章名字和 url -->
[动态规划系列/抢房子.md](https://github.com/labuladong/fucking-algorithm/blob/master/动态规划系列/抢房子.md)

我对如何翻译此文章已经心中有数，我准备将它翻译成：**英文**

<!-- 替换成你的占有时间，尽可能快，主仓库接受的第一个 pr 将会注明翻译者昵称及链接 -->
**预计 3 天内翻译完成**，我会尽可能快地完成翻译，主仓库会对第一个完成的 pull request 添加翻译者昵称/姓名及个人链接。