---
name: 发现问题
about: 我发现了某处链接或者知识点的错误
title: 'bug '
labels: bug
assignees: ''

---

<!--
标题为 bug + 简要描述，内容一定要基于以下模板，根据你的具体内容进行修改 

以上为注释，不会显示在 issue 中。 -->

你好，我发现如下文章有 bug（点击文字可跳转到相关文章）：

[动态规划系列/抢房子.md](https://github.com/labuladong/fucking-algorithm/blob/master/动态规划系列/抢房子.md)

问题描述：

某章图片链接失效/其中的 XXX 内容有误/等等。
